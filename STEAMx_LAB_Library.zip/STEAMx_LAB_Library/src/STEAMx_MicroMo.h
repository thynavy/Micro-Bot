#ifndef STEAMx_MicroMo_h
#define STEAMx_MicroMo_h
#include <Arduino.h>



////////////////////////////////////////////////////////////////////////////////// LED
class button {
  public:

    button();          // Constructor
    int readButton();          
  private:
};

////////////////////////////////////////////////////////////////////////////////// LED
class LED {
  public:
  long last_time;
  int state_blink = 0;
    LED();          // Constructor
    void on();             // Turn LED on
    void off();            // Turn LED off
    void blink(int delayMs); // Blink LED
  private:
    int LEDpin;              // Pin connected to the LED
};
//////////////////////////////////////////////////////////////////////////////////

#endif

