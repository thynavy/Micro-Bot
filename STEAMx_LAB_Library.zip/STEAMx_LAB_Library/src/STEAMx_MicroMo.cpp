#include "STEAMx_MicroMo.h"


////////////////////////////////////////////////////////////////////////////////// LED

button::button() {
  pinMode(6, INPUT_PULLUP);
}
int button::readButton(){
  return digitalRead(6);
}
////////////////////////////////////////////////////////////////////////////////// LED

LED::LED (){
  LEDpin = 2;
  pinMode(LEDpin, OUTPUT);
}

void LED::on() {
  digitalWrite(LEDpin, HIGH);
}

void LED::off() {
  digitalWrite(LEDpin, LOW);
}

void LED::blink(int delayMs) {
  if (millis() - last_time > delayMs) {
    last_time = millis();
    if (state_blink == 0) {
      on();
      state_blink = 1;
    } else if (state_blink == 1) {
      off();
      state_blink = 0;
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////
